#!/bin/bash

filename=""

sed -i 's/  1   /  CH4_sp3 /g' $filename
sed -i 's/  7   /  Mof_Mg  /g' $filename
sed -i 's/  2   /  Mof_Ca  /g' $filename
sed -i 's/  3   /  Mof_Cb  /g' $filename
sed -i 's/  4   /  Mof_Cc  /g' $filename
sed -i 's/  5   /  Mof_Cd  /g' $filename
sed -i 's/  6   /  Mof_H   /g' $filename
sed -i 's/  8   /  Mof_Oa  /g' $filename
sed -i 's/  9   /  Mof_Ob  /g' $filename
sed -i 's/  10  /  Mof_Oc  /g' $filename
